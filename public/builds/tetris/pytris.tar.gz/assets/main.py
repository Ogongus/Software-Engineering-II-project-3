import pygbag.aio as asyncio

import pygame, sys
import random
import json

pygame.init()


# ---------------------------------------------------------------------------
# Best score / level storage
# Saves the user's current high score / level in localStorage so it survives
# reloads. When run normally with Python it falls back to a small JSON file.
# ---------------------------------------------------------------------------
SAVE_KEY = "pytris_best"
SAVE_FILE = "pytris_best.json"


def load_best():
    try:
        if sys.platform == "emscripten":
            import platform

            raw = platform.window.localStorage.getItem(SAVE_KEY)
        else:
            with open(SAVE_FILE, "r") as f:
                raw = f.read()
        if raw:
            data = json.loads(str(raw))
            return int(data["score"]), int(data["level"])
    except Exception:
        pass
    return 0, 1


def save_best(score, level):
    raw = json.dumps({"score": score, "level": level})
    try:
        if sys.platform == "emscripten":
            import platform

            platform.window.localStorage.setItem(SAVE_KEY, raw)
        else:
            with open(SAVE_FILE, "w") as f:
                f.write(raw)
    except Exception:
        pass


# ---------------------------------------------------------------------------
# Simple color declarations that are used for drawing the playing area, 
# tetrominoes, etc
# ---------------------------------------------------------------------------
class Colors:
    dark_grey = (26, 31, 40)
    white = (255, 255, 255)
    dark_blue = (44, 44, 127)
    light_blue = (59, 85, 162)

    # Standard Tetris piece colors
    cyan = (0, 240, 240)  # I
    yellow = (240, 240, 0)  # O
    purple = (160, 0, 240)  # T
    green = (0, 240, 0)  # S
    red = (240, 0, 0)  # Z
    blue = (0, 0, 240)  # J
    orange = (240, 160, 0)  # L

    @classmethod
    def get_cell_colors(cls):
        # Indexed by block id: 0 = empty, 1 = L, 2 = J, 3 = I, 4 = O, 5 = S, 6 = T, 7 = Z
        return [cls.dark_grey, cls.orange, cls.blue, cls.cyan, cls.yellow, cls.green, cls.purple, cls.red]


# ---------------------------------------------------------------------------
# Basic class that helps with determining a tetromino's position on the board
# ---------------------------------------------------------------------------
class Position:
    def __init__(self, row, column):
        self.row = row
        self.column = column


# ---------------------------------------------------------------------------
# Class that builds the grid the game is played on
# Also handles all things relating to how the grid responds to gameplay
# actions like clearing lines
# ---------------------------------------------------------------------------
class Grid:
    def __init__(self):
        self.num_rows = 20
        self.num_cols = 10
        self.cell_size = 30
        self.grid = [[0 for j in range(self.num_cols)] for i in range(self.num_rows)]
        self.colors = Colors.get_cell_colors()

    def print_grid(self):
        for row in range(self.num_rows):
            for column in range(self.num_cols):
                print(self.grid[row][column], end=" ")
            print()

    def is_inside(self, row, column):
        if row >= 0 and row < self.num_rows and column >= 0 and column < self.num_cols:
            return True
        return False

    def is_empty(self, row, column):
        if self.grid[row][column] == 0:
            return True
        return False

    def is_row_full(self, row):
        for column in range(self.num_cols):
            if self.grid[row][column] == 0:
                return False
        return True

    def clear_row(self, row):
        for column in range(self.num_cols):
            self.grid[row][column] = 0

    def move_row_down(self, row, num_rows):
        for column in range(self.num_cols):
            self.grid[row + num_rows][column] = self.grid[row][column]
            self.grid[row][column] = 0

    def clear_full_rows(self):
        completed = 0
        for row in range(self.num_rows - 1, 0, -1):
            if self.is_row_full(row):
                self.clear_row(row)
                completed += 1
            elif completed > 0:
                self.move_row_down(row, completed)
        return completed

    def reset(self):
        for row in range(self.num_rows):
            for column in range(self.num_cols):
                self.grid[row][column] = 0

    def draw(self, screen):
        for row in range(self.num_rows):
            for column in range(self.num_cols):
                cell_value = self.grid[row][column]
                cell_rect = pygame.Rect(
                    column * self.cell_size + 11, row * self.cell_size + 11, self.cell_size - 1, self.cell_size - 1
                )
                pygame.draw.rect(screen, self.colors[cell_value], cell_rect)


# ---------------------------------------------------------------------------
# Base, basic class that defines what a 'block' in the case of this game is
# Contains the functions that handle tetromino rotation, drawing, and movement
# ---------------------------------------------------------------------------
class Block:
    def __init__(self, id):
        self.id = id
        self.cells = {}
        self.cell_size = 30
        self.row_offset = 0
        self.column_offset = 0
        self.rotation_state = 0
        self.colors = Colors.get_cell_colors()

    def move(self, rows, columns):
        self.row_offset += rows
        self.column_offset += columns

    def get_cell_positions(self):
        tiles = self.cells[self.rotation_state]
        moved_tiles = []
        for position in tiles:
            position = Position(position.row + self.row_offset, position.column + self.column_offset)
            moved_tiles.append(position)
        return moved_tiles

    def rotate(self):
        self.rotation_state += 1
        if self.rotation_state == len(self.cells):
            self.rotation_state = 0

    def undo_rotation(self):
        self.rotation_state -= 1
        if self.rotation_state == -1:
            self.rotation_state = len(self.cells) - 1

    def draw(self, screen, offset_x, offset_y):
        tiles = self.get_cell_positions()
        for tile in tiles:
            tile_rect = pygame.Rect(
                offset_x + tile.column * self.cell_size,
                offset_y + tile.row * self.cell_size,
                self.cell_size - 1,
                self.cell_size - 1,
            )
            pygame.draw.rect(screen, self.colors[self.id], tile_rect)


# ---------------------------------------------------------------------------
# Each tetromino shape has its own class that stores the possible positions
# of its 'sublocks'
# Basically, this just makes sure the tetrominoes actually maintain the
# correct shape when rotating them
# ---------------------------------------------------------------------------
class LBlock(Block):
    def __init__(self):
        super().__init__(id=1)
        self.cells = {
            0: [Position(0, 2), Position(1, 0), Position(1, 1), Position(1, 2)],
            1: [Position(0, 1), Position(1, 1), Position(2, 1), Position(2, 2)],
            2: [Position(1, 0), Position(1, 1), Position(1, 2), Position(2, 0)],
            3: [Position(0, 0), Position(0, 1), Position(1, 1), Position(2, 1)],
        }
        self.move(0, 3)


class JBlock(Block):
    def __init__(self):
        super().__init__(id=2)
        self.cells = {
            0: [Position(0, 0), Position(1, 0), Position(1, 1), Position(1, 2)],
            1: [Position(0, 1), Position(0, 2), Position(1, 1), Position(2, 1)],
            2: [Position(1, 0), Position(1, 1), Position(1, 2), Position(2, 2)],
            3: [Position(0, 1), Position(1, 1), Position(2, 0), Position(2, 1)],
        }
        self.move(0, 3)


class IBlock(Block):
    def __init__(self):
        super().__init__(id=3)
        self.cells = {
            0: [Position(1, 0), Position(1, 1), Position(1, 2), Position(1, 3)],
            1: [Position(0, 2), Position(1, 2), Position(2, 2), Position(3, 2)],
            2: [Position(2, 0), Position(2, 1), Position(2, 2), Position(2, 3)],
            3: [Position(0, 1), Position(1, 1), Position(2, 1), Position(3, 1)],
        }
        self.move(-1, 3)


class OBlock(Block):
    def __init__(self):
        super().__init__(id=4)
        self.cells = {0: [Position(0, 0), Position(0, 1), Position(1, 0), Position(1, 1)]}
        self.move(0, 4)


class SBlock(Block):
    def __init__(self):
        super().__init__(id=5)
        self.cells = {
            0: [Position(0, 1), Position(0, 2), Position(1, 0), Position(1, 1)],
            1: [Position(0, 1), Position(1, 1), Position(1, 2), Position(2, 2)],
            2: [Position(1, 1), Position(1, 2), Position(2, 0), Position(2, 1)],
            3: [Position(0, 0), Position(1, 0), Position(1, 1), Position(2, 1)],
        }
        self.move(0, 3)


class TBlock(Block):
    def __init__(self):
        super().__init__(id=6)
        self.cells = {
            0: [Position(0, 1), Position(1, 0), Position(1, 1), Position(1, 2)],
            1: [Position(0, 1), Position(1, 1), Position(1, 2), Position(2, 1)],
            2: [Position(1, 0), Position(1, 1), Position(1, 2), Position(2, 1)],
            3: [Position(0, 1), Position(1, 0), Position(1, 1), Position(2, 1)],
        }
        self.move(0, 3)


class ZBlock(Block):
    def __init__(self):
        super().__init__(id=7)
        self.cells = {
            0: [Position(0, 0), Position(0, 1), Position(1, 1), Position(1, 2)],
            1: [Position(0, 2), Position(1, 1), Position(1, 2), Position(2, 1)],
            2: [Position(1, 0), Position(1, 1), Position(2, 1), Position(2, 2)],
            3: [Position(0, 1), Position(1, 0), Position(1, 1), Position(2, 0)],
        }
        self.move(0, 3)


# ---------------------------------------------------------------------------
# Generic game class, handles score calculation, tetromino movement, and
# randomness
# ---------------------------------------------------------------------------
class Game:
    def __init__(self):
        self.grid = Grid()
        self.blocks = [IBlock(), JBlock(), LBlock(), OBlock(), SBlock(), TBlock(), ZBlock()]
        self.current_block = self.get_random_block()
        self.next_block = self.get_random_block()
        self.game_over = False
        self.score = 0
        self.rotate_sound = pygame.mixer.Sound("Sounds/rotate.ogg")
        self.clear_sound = pygame.mixer.Sound("Sounds/clear.ogg")

        # Music is loaded here but only starts playing once the game is started
        pygame.mixer.music.load("Sounds/music.ogg")

    def update_score(self, lines_cleared, move_down_points):
        if lines_cleared == 1:
            self.score += 100
        elif lines_cleared == 2:
            self.score += 300
        elif lines_cleared == 3:
            self.score += 500
        self.score += move_down_points

    def get_random_block(self):
        if len(self.blocks) == 0:
            self.blocks = [IBlock(), JBlock(), LBlock(), OBlock(), SBlock(), TBlock(), ZBlock()]
        block = random.choice(self.blocks)
        self.blocks.remove(block)
        return block

    def move_left(self):
        self.current_block.move(0, -1)
        if self.block_inside() == False or self.block_fits() == False:
            self.current_block.move(0, 1)

    def move_right(self):
        self.current_block.move(0, 1)
        if self.block_inside() == False or self.block_fits() == False:
            self.current_block.move(0, -1)

    def move_down(self):
        self.current_block.move(1, 0)
        if self.block_inside() == False or self.block_fits() == False:
            self.current_block.move(-1, 0)
            self.lock_block()

    def lock_block(self):
        tiles = self.current_block.get_cell_positions()
        for position in tiles:
            self.grid.grid[position.row][position.column] = self.current_block.id
        self.current_block = self.next_block
        self.next_block = self.get_random_block()
        rows_cleared = self.grid.clear_full_rows()
        if rows_cleared > 0:
            self.clear_sound.play()
            self.update_score(rows_cleared, 0)
        if self.block_fits() == False:
            self.game_over = True

    def reset(self):
        self.grid.reset()
        self.blocks = [IBlock(), JBlock(), LBlock(), OBlock(), SBlock(), TBlock(), ZBlock()]
        self.current_block = self.get_random_block()
        self.next_block = self.get_random_block()
        self.score = 0

    def block_fits(self):
        tiles = self.current_block.get_cell_positions()
        for tile in tiles:
            if self.grid.is_empty(tile.row, tile.column) == False:
                return False
        return True

    def rotate(self):
        self.current_block.rotate()
        if self.block_inside() == False or self.block_fits() == False:
            self.current_block.undo_rotation()
        else:
            self.rotate_sound.play()

    def block_inside(self):
        tiles = self.current_block.get_cell_positions()
        for tile in tiles:
            if self.grid.is_inside(tile.row, tile.column) == False:
                return False
        return True

    def draw(self, screen):
        self.grid.draw(screen)
        self.current_block.draw(screen, 11, 11)

        if self.next_block.id == 3:
            self.next_block.draw(screen, 255, 290)
        elif self.next_block.id == 4:
            self.next_block.draw(screen, 255, 280)
        else:
            self.next_block.draw(screen, 270, 270)


# ---------------------------------------------------------------------------
# Main loop
# ---------------------------------------------------------------------------
async def main():
    title_font = pygame.font.Font(None, 40)
    score_surface = title_font.render("Score", True, Colors.white)
    next_surface = title_font.render("Next", True, Colors.white)
    game_over_surface = title_font.render("GAME OVER", True, Colors.white)
    paused_surface = title_font.render("PAUSED", True, Colors.white)

    popup_font = pygame.font.Font(None, 30)
    retry_surface = popup_font.render("Press ENTER to retry", True, Colors.white)
    menu_surface = popup_font.render("Press M for main menu", True, Colors.white)
    popup_rect = pygame.Rect(0, 0, 360, 200)
    popup_rect.center = (250, 310)

    best_score, best_level = load_best()

    start_surface = pygame.font.Font(None, 50).render("PYTRIS", True, Colors.white)
    instruction_surface = pygame.font.Font(None, 30).render("PRESS AN ARROW KEY TO START!", True, Colors.white)

    hint_font = pygame.font.Font(None, 22)
    pause_hint_surface = hint_font.render("Press 'P' to pause", True, Colors.white)
    resume_hint_surface = hint_font.render("Press 'P' to resume", True, Colors.white)

    score_rect = pygame.Rect(320, 55, 170, 60)
    next_rect = pygame.Rect(320, 215, 170, 180)

    screen = pygame.display.set_mode((500, 620))
    pygame.display.set_caption("Python Tetris")

    clock = pygame.time.Clock()

    game = Game()
    game_started = False
    paused = False

    # Holding the down arrow drops the piece at a steady pace (milliseconds per step)
    down_held = False
    soft_drop_interval = 50
    last_soft_drop = 0

    # Difficulty: the level goes up every 100 points, and the falling speed
    # increases every 10 levels (1000 points), down to a fastest speed limit.
    # The fastest speed limit is basically impossible to play on, but I made
    # sure to cap it just in case
    base_fall_interval = 800  # milliseconds per grid step at the start
    min_fall_interval = 100  # fastest allowed speed
    speed_step = 100  # milliseconds removed at each speed increase
    points_per_level = 100
    levels_per_speedup = 10

    last_update = pygame.time.get_ticks()

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            if event.type == pygame.KEYUP:
                if event.key == pygame.K_DOWN:
                    down_held = False

            if event.type == pygame.KEYDOWN:
                if not game_started:
                    if event.key in (pygame.K_LEFT, pygame.K_RIGHT, pygame.K_UP, pygame.K_DOWN):
                        game_started = True
                        last_update = pygame.time.get_ticks()
                        pygame.mixer.music.play(-1)
                    continue

                # Pause / resume with P (not available on the game over screen)
                if event.key == pygame.K_p and game.game_over == False:
                    paused = not paused
                    if paused:
                        pygame.mixer.music.pause()
                        down_held = False
                    else:
                        pygame.mixer.music.unpause()
                        last_update = pygame.time.get_ticks()
                    continue

                if paused:
                    continue

                if game.game_over == True:
                    if event.key in (pygame.K_RETURN, pygame.K_KP_ENTER):
                        # Retry immediately
                        game.reset()
                        game.game_over = False
                        down_held = False
                        last_update = pygame.time.get_ticks()
                    elif event.key == pygame.K_m:
                        # Go back to the main menu
                        game.reset()
                        game.game_over = False
                        game_started = False
                        paused = False
                        down_held = False
                        pygame.mixer.music.stop()
                    continue

                if event.key == pygame.K_LEFT and game.game_over == False:
                    game.move_left()
                if event.key == pygame.K_RIGHT and game.game_over == False:
                    game.move_right()
                if event.key == pygame.K_DOWN and game.game_over == False:
                    game.move_down()
                    game.update_score(0, 1)
                    down_held = True
                    last_soft_drop = pygame.time.get_ticks()
                if event.key == pygame.K_UP and game.game_over == False:
                    game.rotate()

        # Title screen state
        if not game_started:
            screen.fill(Colors.dark_blue)

            screen.blit(start_surface, start_surface.get_rect(center=(250, 220)))
            screen.blit(instruction_surface, instruction_surface.get_rect(center=(250, 290)))

            best_score_surface = popup_font.render(f"BEST SCORE: {best_score}", True, Colors.white)
            best_level_surface = popup_font.render(f"BEST LEVEL: {best_level}", True, Colors.white)
            screen.blit(best_score_surface, best_score_surface.get_rect(center=(250, 380)))
            screen.blit(best_level_surface, best_level_surface.get_rect(center=(250, 415)))

        else:
            current_time = pygame.time.get_ticks()

            level = game.score // points_per_level + 1
            speedups = (level - 1) // levels_per_speedup
            fall_interval = max(min_fall_interval, base_fall_interval - speed_step * speedups)

            if game.game_over:
                down_held = False

            if paused or game.game_over:
                # Keep the timer fresh so the piece doesn't jump when resuming
                last_update = current_time
            else:
                # Soft drop while the down arrow is held
                if down_held and current_time - last_soft_drop >= soft_drop_interval:
                    game.move_down()
                    game.update_score(0, 1)
                    last_soft_drop = current_time

                # Automatic fall, speed depends on the current level
                if current_time - last_update >= fall_interval:
                    if game.game_over == False:
                        game.move_down()
                    last_update = current_time

            # Record a new best score / level as soon as it is reached
            if game.score > best_score:
                best_score = game.score
                best_level = game.score // points_per_level + 1
                save_best(best_score, best_level)

            # Drawing
            score_value_surface = title_font.render(str(game.score), True, Colors.white)
            level_surface = title_font.render(f"Level {level}", True, Colors.white)

            screen.fill(Colors.dark_blue)
            screen.blit(score_surface, (365, 20, 50, 50))
            screen.blit(next_surface, (375, 180, 50, 50))

            if paused:
                screen.blit(paused_surface, (350, 450, 50, 50))

            pygame.draw.rect(screen, Colors.light_blue, score_rect, 0, 10)
            screen.blit(score_value_surface, score_value_surface.get_rect(centerx=score_rect.centerx, centery=score_rect.centery))
            screen.blit(level_surface, level_surface.get_rect(centerx=score_rect.centerx, centery=145))

            hint_surface = resume_hint_surface if paused else pause_hint_surface
            screen.blit(hint_surface, hint_surface.get_rect(bottomright=(490, 610)))
            pygame.draw.rect(screen, Colors.light_blue, next_rect, 0, 10)
            game.draw(screen)

            # Game over popup
            if game.game_over:
                final_score_surface = popup_font.render(f"Score: {game.score}", True, Colors.white)
                pygame.draw.rect(screen, Colors.dark_blue, popup_rect, 0, 10)
                pygame.draw.rect(screen, Colors.white, popup_rect, 3, 10)
                screen.blit(game_over_surface, game_over_surface.get_rect(center=(250, 250)))
                screen.blit(final_score_surface, final_score_surface.get_rect(center=(250, 295)))
                screen.blit(retry_surface, retry_surface.get_rect(center=(250, 345)))
                screen.blit(menu_surface, menu_surface.get_rect(center=(250, 375)))

        pygame.display.update()
        clock.tick(60)
        await asyncio.sleep(0)


if __name__ == "__main__":
    asyncio.run(main())
